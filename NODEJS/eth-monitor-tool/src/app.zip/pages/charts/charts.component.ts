import { Component } from '@angular/core';

@Component({
  selector: 'app-charts',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ChartsComponent {
}
