import { Component } from '@angular/core';

@Component({
  selector: 'app-dropdown-buttons',
  styleUrls: ['./dropdown-button.component.scss'],
  templateUrl: './dropdown-button.component.html',
})

export class DropdownButtonsComponent {
}
