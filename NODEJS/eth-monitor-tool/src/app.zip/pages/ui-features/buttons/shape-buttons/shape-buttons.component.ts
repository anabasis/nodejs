import { Component } from '@angular/core';

@Component({
  selector: 'app-shape-buttons',
  styleUrls: ['./shape-buttons.component.scss'],
  templateUrl: './shape-buttons.component.html',
})
export class ShapeButtonsComponent {
}
