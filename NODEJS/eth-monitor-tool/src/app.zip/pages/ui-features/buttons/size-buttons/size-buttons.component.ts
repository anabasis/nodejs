import { Component } from '@angular/core';

@Component({
  selector: 'app-size-buttons',
  styleUrls: ['./size-buttons.component.scss'],
  templateUrl: './size-buttons.component.html',
})
export class SizeButtonsComponent {
}
