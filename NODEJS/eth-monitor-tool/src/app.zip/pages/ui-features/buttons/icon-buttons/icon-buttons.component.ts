import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-buttons',
  styleUrls: ['./icon-buttons.component.scss'],
  templateUrl: './icon-buttons.component.html',
})
export class IconButtonsComponent {
}
