import { Component } from '@angular/core';

@Component({
  selector: 'app-labeled-actions-group',
  styleUrls: ['./labeled-actions-group.component.scss'],
  templateUrl: './labeled-actions-group.component.html',
})
export class LabeledActionsGroupComponent {
}
