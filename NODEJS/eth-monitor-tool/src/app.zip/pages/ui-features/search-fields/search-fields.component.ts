import { Component } from '@angular/core';

@Component({
    selector: 'app-search-fields',
    templateUrl: 'search-fields.component.html',
})
export class SearchComponent {
}
