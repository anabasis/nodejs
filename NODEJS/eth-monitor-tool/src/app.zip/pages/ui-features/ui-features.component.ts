import { Component } from '@angular/core';

@Component({
  selector: 'app-ui-features',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class UiFeaturesComponent {
}
